///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ============
// manage the preparing and rendering of 3D scenes - textures, materials, lighting
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager *pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ,
	glm::vec3 offset)
{
	// variables for this method
	glm::mat4 model;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ + offset);

	model = translation * rotationZ * rotationY * rotationX * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, model);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/

/***********************************************************
 *  LoadSceneTextures()
 *
 *  Loads textures into GPU memory and binds them
 ***********************************************************/
void SceneManager::LoadSceneTextures()
{
	CreateGLTexture("textures/360_F_152794750_gjr9dhcxlaYen9CsjDYuYDqwy0S8vitS.jpg", "glass");
	CreateGLTexture("textures/360_F_1404871824_YCYuzYPo53lt2kmoJAr41FN8ebGvD3Yw.jpg", "cap");
	CreateGLTexture("textures/vanitytable wood color.jpg", "wood");
	CreateGLTexture("textures/c3024f69614d2b3d13d3135fe615fb6e.jpg", "mirror");
	CreateGLTexture("textures/1000_F_481596045_k1bQ4dhDdtij4gftXiFq1kT7PCou7i7a.jpg", "gold");
	CreateGLTexture("textures/istockphoto-154207518-612x612.jpg", "bristle");
	CreateGLTexture("textures/istockphoto-1163531118-1024x1024.jpg", "floor");
	CreateGLTexture("textures/7e20de6fd5c9f2411a6a816e54ff3277.jpg", "label");
	CreateGLTexture("textures/1000_F_93332207_ObdaTaHLq41eapLJJa5QVN6OrECiK2PY.jpg", "pot");
	CreateGLTexture("textures/360_F_23040694_lmQSrn05OnbYYiCMGN655ToXyUffFPLr.jpg", "cactus");
	CreateGLTexture("textures/fluffy.jpg", "pillow");

	BindGLTextures();
}

/***********************************************************
 *  DefineObjectMaterials()
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	// Wood material 
	OBJECT_MATERIAL woodMaterial;
	woodMaterial.diffuseColor = glm::vec3(0.5f, 0.5f, 0.5f);
	woodMaterial.specularColor = glm::vec3(0.6f, 0.6f, 0.6f);
	woodMaterial.shininess = 5.0f;
	woodMaterial.tag = "wood";
	m_objectMaterials.push_back(woodMaterial);

	// Glass material 
	OBJECT_MATERIAL glassMaterial;
	glassMaterial.diffuseColor = glm::vec3(0.2f, 0.2f, 0.2f);
	glassMaterial.specularColor = glm::vec3(1.0f, 1.0f, 1.0f);
	glassMaterial.shininess = 128.0;
	glassMaterial.tag = "glass";
	m_objectMaterials.push_back(glassMaterial);

	// Matte material
	OBJECT_MATERIAL matteMaterial;
	matteMaterial.diffuseColor = glm::vec3(0.5f, 0.5f, 0.5f);
	matteMaterial.specularColor = glm::vec3(0.1f, 0.1f, 0.1f);
	matteMaterial.shininess = 1.0f;                            
	matteMaterial.tag = "matte";
	m_objectMaterials.push_back(matteMaterial);

	// Fabric material
	OBJECT_MATERIAL fabricMaterial;
	fabricMaterial.diffuseColor = glm::vec3(1.0f, 1.0f, 1.0f);
	fabricMaterial.specularColor = glm::vec3(0.01f, 0.01f, 0.01f);
	fabricMaterial.shininess = 2.0f;
	fabricMaterial.tag = "fabric";
	m_objectMaterials.push_back(fabricMaterial);
}

/***********************************************************
 *  SetupSceneLights()
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	m_pShaderManager->setBoolValue(g_UseLightingName, true);

	// Light 1: Soft pink tone
	m_pShaderManager->setVec3Value("pointLights[0].position", glm::vec3(5.0f, 10.0f, 8.0f));
	m_pShaderManager->setVec3Value("pointLights[0].ambient", glm::vec3(0.2f, 0.15f, 0.15f));
	m_pShaderManager->setVec3Value("pointLights[0].diffuse", glm::vec3(1.0f, 0.7f, 0.8f));  
	m_pShaderManager->setVec3Value("pointLights[0].specular", glm::vec3(1.0f, 0.8f, 0.8f));
	m_pShaderManager->setBoolValue("pointLights[0].bActive", true);

	// Light 2: Soft purple fill
	m_pShaderManager->setVec3Value("pointLights[1].position", glm::vec3(-5.0f, 5.0f, 0.0f));
	m_pShaderManager->setVec3Value("pointLights[1].ambient", glm::vec3(0.15f, 0.1f, 0.15f));
	m_pShaderManager->setVec3Value("pointLights[1].diffuse", glm::vec3(0.5f, 0.3f, 0.6f));  
	m_pShaderManager->setVec3Value("pointLights[1].specular", glm::vec3(0.3f, 0.2f, 0.4f));
	m_pShaderManager->setBoolValue("pointLights[1].bActive", true);

	// Light 3: Rim light to help objects stand out
	m_pShaderManager->setVec3Value("pointLights[2].position", glm::vec3(0.0f, 5.0f, -5.0f));
	m_pShaderManager->setVec3Value("pointLights[2].ambient", glm::vec3(0.05f, 0.05f, 0.05f));
	m_pShaderManager->setVec3Value("pointLights[2].diffuse", glm::vec3(0.4f, 0.4f, 0.4f)); 
	m_pShaderManager->setVec3Value("pointLights[2].specular", glm::vec3(0.5f, 0.5f, 0.5f));
	m_pShaderManager->setBoolValue("pointLights[2].bActive", true);

	// Camera view position
	m_pShaderManager->setVec3Value("viewPosition", glm::vec3(0.0f, 3.0f, 12.0f));
}

/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene

	//Load textures
	LoadSceneTextures();
	DefineObjectMaterials(); // Initialize materials
	SetupSceneLights();      // Initialize lights

	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadBoxMesh(); 
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by 
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/

	// --- Floor Plane ---
	SetTextureUVScale(4.0f, 2.0f);

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(20.0f, 1.0f, 10.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("floor");

	SetShaderMaterial("wood");

	m_basicMeshes->DrawPlaneMesh();

	SetTextureUVScale(1.0f, 1.0f);

/****************************************************************/

// --- Vanity Table Surface ---
	scaleXYZ = glm::vec3(12.0f, 0.5f, 6.0f); 

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(0.0f, 4.0f, 0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("wood");
	SetTextureUVScale(3.0f, 3.0f);

	SetShaderMaterial("wood");

	m_basicMeshes->DrawBoxMesh();


// --- Vanity Left Side Wall ---
	scaleXYZ = glm::vec3(0.2f, 4.0f, 6.0f); 
	
	positionXYZ = glm::vec3(-5.9f, 2.0f, 0.0f);

	SetTransformations(
		scaleXYZ,
		0.0f, 0.0f, 0.0f, 
		positionXYZ);

	SetShaderTexture("wood"); 

	SetShaderMaterial("wood");

	m_basicMeshes->DrawBoxMesh();


// --- Vanity Right Side Wall ---
	positionXYZ = glm::vec3(5.9f, 2.0f, 0.0f);

	SetTransformations(
		scaleXYZ, 
		0.0f, 0.0f, 0.0f, 
		positionXYZ);

	SetShaderTexture("wood");

	SetShaderMaterial("wood"); 

	m_basicMeshes->DrawBoxMesh();


// --- Vanity Backboard ---
	scaleXYZ = glm::vec3(12.0f, 8.0f, 0.2f); 

	positionXYZ = glm::vec3(0.0f, 5.0f, -2.9f);

	SetTransformations(
		scaleXYZ, 
		0.0f, 0.0f, 0.0f, 
		positionXYZ);

	SetShaderTexture("wood"); 

	SetShaderMaterial("wood");

	m_basicMeshes->DrawBoxMesh();


// --- Vanity Lower Left Shelf ---
 scaleXYZ = glm::vec3(3.5f, 0.2f, 2.0f); // A small wooden shelf next to the mirror 

 positionXYZ = glm::vec3(-3.5f, 6.0f, -1.8f);

	SetTransformations(
		scaleXYZ,
		0.0f, 0.0f, 0.0f, 
		positionXYZ);

	SetShaderTexture("wood"); 
	
	
	SetShaderMaterial("wood"); 
	
	m_basicMeshes->DrawBoxMesh();


// --- Vanity Higher Left Shelf ---
scaleXYZ = glm::vec3(3.5f, 0.2f, 2.0f); 

positionXYZ = glm::vec3(-3.5f, 7.5f, -1.8f);

	SetTransformations(scaleXYZ, 
		0.0f, 0.0f, 0.0f, 
		positionXYZ);

	SetShaderTexture("wood"); 
	
	SetShaderMaterial("wood"); 
	
	m_basicMeshes->DrawBoxMesh();


// --- Vanity Mirror ---
	 scaleXYZ = glm::vec3(7.0f, 5.0f, 0.1f); // Mirror attached to backboard
	
	 positionXYZ = glm::vec3(2.0f, 7.0f, -2.7f);

	SetTransformations(
		scaleXYZ, 
		0.0f, 0.0f, 0.0f, 
		positionXYZ);

	SetTextureUVScale(1.0f, 1.0f);

	SetShaderTexture("mirror");

	SetShaderMaterial("glass"); 
	
	m_basicMeshes->DrawBoxMesh();


// --- Gold Product (Top Shelf) ---
scaleXYZ = glm::vec3(0.4f, 0.8f, 0.4f); // Tiny cylinder to represent a small product 

positionXYZ = glm::vec3(-3.5f, 7.5f, -1.8f);

	SetTransformations(scaleXYZ, 
		0.0f, 0.0f, 0.0f, 
		positionXYZ);

	SetTextureUVScale(1.0f, 1.0f);

	 SetShaderTexture("gold"); 

	SetShaderMaterial("glass");

	m_basicMeshes->DrawCylinderMesh();


// --- Lipstick ---
  scaleXYZ = glm::vec3(0.3f, 0.7f, 0.3f); 
  
  positionXYZ = glm::vec3(2.5f, 4.35f, 1.0f); // Sits on table

	SetTransformations(
		scaleXYZ,
		0.0f, 0.0f, 0.0f, 
		positionXYZ); 

	SetShaderMaterial("matte");

	SetShaderColor(0.1f, 0.1f, 0.1f, 1.0f); // Black 

	m_basicMeshes->DrawBoxMesh();


// Lipstick Neck
	scaleXYZ = glm::vec3(0.2f, 0.3f, 0.2f); 
	
	positionXYZ = glm::vec3(2.5f, 4.72f, 1.0f);

	SetTransformations(
		scaleXYZ, 
		0.0f, 0.0f, 0.0f, 
		positionXYZ); 
	
	SetShaderTexture("gold"); 
	
	m_basicMeshes->DrawCylinderMesh();


// Lipstick Red Tip
	scaleXYZ = glm::vec3(0.10f, 0.4f, 0.15f);
	
	positionXYZ = glm::vec3(2.5f, 5.0f, 1.0f);

	SetTransformations(
		scaleXYZ, 
		15.0f, 0.0f, 0.0f,
		positionXYZ); 
	
	SetShaderMaterial("matte");

	SetShaderColor(0.8f, 0.0f, 0.0f, 1.0f); // Deep red
	
	m_basicMeshes->DrawCylinderMesh();


// --- Nail Polish Set ---
	// Polish 1: Red
	scaleXYZ = glm::vec3(0.4f, 0.45f, 0.4f);

    positionXYZ = glm::vec3(-3.5f, 6.25f, -1.8f);

	SetTransformations(
		scaleXYZ,
		0.0f, 0.0f, 0.0f, 
		positionXYZ);

     SetShaderColor(0.8f, 0.0f, 0.0f, 1.0f);
	 
	 SetShaderMaterial("glass");

	m_basicMeshes->DrawBoxMesh();

	// Nail Polish - Gold Handle
	scaleXYZ = glm::vec3(0.12f, 0.5f, 0.12f);

	positionXYZ = glm::vec3(-3.5f, 6.50f, -1.8f);

	SetTransformations(
		scaleXYZ, 
		0.0f, 0.0f, 0.0f, 
		positionXYZ);

	SetShaderTexture("gold"); 
	
	SetShaderMaterial("glass");

	m_basicMeshes->DrawCylinderMesh();


	// Polish 2: Pink
	scaleXYZ = glm::vec3(0.4f, 0.45f, 0.4f);
	positionXYZ = glm::vec3(-2.8f, 6.25f, -1.8f); 

	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderColor(1.0f, 0.4f, 0.7f, 1.0f); 
	SetShaderMaterial("glass");
	m_basicMeshes->DrawBoxMesh();

	// Handle
	scaleXYZ = glm::vec3(0.12f, 0.5f, 0.12f);
	positionXYZ = glm::vec3(-2.8f, 6.50f, -1.8f);

	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("gold");
	m_basicMeshes->DrawCylinderMesh();


// Polish 3: Purple
	scaleXYZ = glm::vec3(0.4f, 0.45f, 0.4f);
	positionXYZ = glm::vec3(-2.1f, 6.25f, -1.8f); 

	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderColor(0.5f, 0.0f, 0.5f, 1.0f); 
	SetShaderMaterial("glass");
	m_basicMeshes->DrawBoxMesh();

	// Handle
	scaleXYZ = glm::vec3(0.12f, 0.5f, 0.12f);
	positionXYZ = glm::vec3(-2.1f, 6.50f, -1.8f);

	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("gold");
	m_basicMeshes->DrawCylinderMesh();


	// Polish 4: Teal
	scaleXYZ = glm::vec3(0.4f, 0.45f, 0.4f);
	positionXYZ = glm::vec3(-4.2f, 6.25f, -1.8f);

	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderColor(0.0f, 0.6f, 0.6f, 1.0f);
	SetShaderMaterial("glass");
	m_basicMeshes->DrawBoxMesh();

	// Handle
	scaleXYZ = glm::vec3(0.12f, 0.5f, 0.12f);
	positionXYZ = glm::vec3(-4.2f, 6.50f, -1.8f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("gold");
	m_basicMeshes->DrawCylinderMesh();

	// Polish 5: Mocha
	scaleXYZ = glm::vec3(0.4f, 0.45f, 0.4f);
	positionXYZ = glm::vec3(-4.9f, 6.25f, -1.8f);

	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	SetShaderColor(0.4f, 0.25f, 0.15f, 1.0f);

	SetShaderMaterial("glass");
	m_basicMeshes->DrawBoxMesh();

	// Handle
	scaleXYZ = glm::vec3(0.12f, 0.5f, 0.12f);
	positionXYZ = glm::vec3(-4.9f, 6.50f, -1.8f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("gold");
	m_basicMeshes->DrawCylinderMesh();


// --- Perfume Bottle ---
	// Main body
	scaleXYZ = glm::vec3(1.4f, 2.8f, 0.8f); 

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(0.0f, 5.4f, 0.0f); 

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("glass");

	SetTextureUVScale(1.0f, 1.0f);

	SetShaderMaterial("glass");

	m_basicMeshes->DrawBoxMesh();


	// Neck
	scaleXYZ = glm::vec3(0.35f, 0.4f, 0.35f); 

	positionXYZ = glm::vec3(0.0f, 6.8f, 0.0); // sits on top of bottle body

	SetTransformations(
		scaleXYZ,
		0.0f, 0.0f, 0.0f,
		positionXYZ);

	SetShaderTexture("cap");
	SetTextureUVScale(1.0f, 1.0f);

	SetShaderMaterial("glass");

	m_basicMeshes->DrawCylinderMesh();


	// Cap
	scaleXYZ = glm::vec3(0.9f, 0.35f, 0.9f);

	positionXYZ = glm::vec3(0.0f, 7.1f, 0.0f); // sits on top of neck

	SetTransformations(
		scaleXYZ,
		0.0f, 0.0f, 0.0f,
		positionXYZ);

	SetShaderTexture("cap");
	SetTextureUVScale(1.0f, 1.0f);

	SetShaderMaterial("glass");

	m_basicMeshes->DrawBoxMesh();

// --- Perfume Label ---
	scaleXYZ = glm::vec3(0.6f, 0.6f, 0.01f); // Label placed on the front of the bottle

	positionXYZ = glm::vec3(0.0f, 5.4f, 0.41f);

	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	SetShaderTexture("label");

	SetShaderMaterial("wood");

	m_basicMeshes->DrawBoxMesh();

// --- Makeup Brush ---
	// Handle
	scaleXYZ = glm::vec3(0.08f, 1.2f, 0.08f); // Sitting ontop of vanity left side

	positionXYZ = glm::vec3(-3.5f, 4.35f, 1.0f);

	SetTransformations(
		scaleXYZ,
		0.0f, 20.0f, 90.0f, 
		positionXYZ);

	SetShaderColor(0.1f, 0.1f, 0.1f, 1.0f); // Black 

	m_basicMeshes->DrawCylinderMesh();

	// Bristles
	scaleXYZ = glm::vec3(0.15f, 0.4f, 0.15f);

	positionXYZ = glm::vec3(-4.4f, 4.35f, 1.0f);

	SetTransformations(
		scaleXYZ,
		0.0f, 0.0f, 90.0f,
		positionXYZ);

	SetShaderMaterial("matte");

	SetShaderTexture("bristle");

	m_basicMeshes->DrawCylinderMesh();


// --- Potted Plant ---
	// Pot
	scaleXYZ = glm::vec3(0.5f, 0.6f, 0.5f);
	positionXYZ = glm::vec3(4.5f, 4.3f, 1.5f); // Right front corner of the table

	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	SetShaderTexture("pot");

	SetShaderMaterial("wood");

	m_basicMeshes->DrawCylinderMesh();


// Cactus body
	scaleXYZ = glm::vec3(0.25f, 1.2f, 0.25f); 
	positionXYZ = glm::vec3(4.5f, 4.9f, 1.5f); // Centered in the pot

	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	SetShaderTexture("cactus");

	m_basicMeshes->DrawCylinderMesh();


	// --- Cactus Left Arm ---
	scaleXYZ = glm::vec3(0.15f, 0.4f, 0.15f);

	positionXYZ = glm::vec3(4.7f, 5.3f, 1.5f);

	SetTransformations(scaleXYZ, 0.0f, 0.0f, -45.0f, positionXYZ);

	m_basicMeshes->DrawCylinderMesh();


	// --- Cactus Right Arm ---
	scaleXYZ = glm::vec3(0.15f, 0.4f, 0.15f);
	positionXYZ = glm::vec3(4.3f, 5.1f, 1.5f);

	SetTransformations(scaleXYZ, 0.0f, 0.0f, 45.0f, positionXYZ);

	m_basicMeshes->DrawCylinderMesh();

// --- Vanity Bench ---
	// Bench seat
	scaleXYZ = glm::vec3(4.0f, 0.3f, 2.0f); 
	positionXYZ = glm::vec3(0.0f, 2.0f, 4.0f); // Placed in front of the table

	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	SetShaderTexture("wood"); 
	SetShaderMaterial("wood");
	m_basicMeshes->DrawBoxMesh();

// Bench side panels
	scaleXYZ = glm::vec3(0.2f, 2.0f, 2.0f);

	SetTextureUVScale(2.0f, 2.0f);

    //Left Panel
	positionXYZ = glm::vec3(-1.9f, 1.0f, 4.0f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("wood");
	SetShaderMaterial("wood");
	m_basicMeshes->DrawBoxMesh();

	// Right Panel
	positionXYZ = glm::vec3(1.9f, 1.0f, 4.0f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("wood");
	SetShaderMaterial("wood");
	m_basicMeshes->DrawBoxMesh();


	// --- Bench pillow ---
	scaleXYZ = glm::vec3(3.6f, 0.75f, 1.45f);

	positionXYZ = glm::vec3(0.0f, 2.45f, 4.0f);

	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	SetTextureUVScale(1.3f, 1.3f);

	SetShaderTexture("pillow");

	SetShaderMaterial("fabric");

	m_basicMeshes->DrawBoxMesh();

}
